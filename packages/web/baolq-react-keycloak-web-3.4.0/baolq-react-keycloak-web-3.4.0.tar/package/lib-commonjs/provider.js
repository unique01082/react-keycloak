"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReactKeycloakProvider = void 0;
var react_keycloak_core_1 = require("@baolq/react-keycloak-core");
var context_1 = require("./context");
exports.ReactKeycloakProvider = (0, react_keycloak_core_1.createAuthProvider)(context_1.reactKeycloakWebContext);
//# sourceMappingURL=provider.js.map