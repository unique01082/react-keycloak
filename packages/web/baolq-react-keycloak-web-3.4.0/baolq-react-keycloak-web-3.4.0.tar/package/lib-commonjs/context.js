"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReactKeycloakWebContextConsumer = exports.reactKeycloakWebContext = void 0;
var react_keycloak_core_1 = require("@baolq/react-keycloak-core");
// @ts-ignore
exports.reactKeycloakWebContext = (0, react_keycloak_core_1.createAuthContext)();
exports.ReactKeycloakWebContextConsumer = exports.reactKeycloakWebContext.Consumer;
//# sourceMappingURL=context.js.map