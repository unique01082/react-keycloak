export declare function useKeycloak(): {
    initialized: boolean;
    keycloak: import("keycloak-js").KeycloakInstance;
};
