/// <reference types="react" />
export declare const ReactKeycloakProvider: {
    new (props: import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance> | Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>): {
        state: {
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        };
        componentDidMount(): void;
        componentDidUpdate({ authClient: prevAuthClient, initOptions: prevInitOptions, }: import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>): void;
        init(): void;
        onError: (event: import("@baolq/react-keycloak-core").AuthClientEvent) => (error?: import("@baolq/react-keycloak-core").AuthClientError | undefined) => void;
        updateState: (event: import("@baolq/react-keycloak-core").AuthClientEvent) => () => void;
        refreshToken: (event: import("@baolq/react-keycloak-core").AuthClientEvent) => () => void;
        render(): JSX.Element;
        context: any;
        setState<K extends keyof {
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>(state: {
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        } | Pick<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }, K> | ((prevState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>, props: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>) => {
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        } | Pick<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }, K> | null) | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>> & Readonly<{
            children?: import("react").ReactNode;
        }>;
        refs: {
            [key: string]: import("react").ReactInstance;
        };
        shouldComponentUpdate?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: import("react").ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, prevState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>): any;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>, nextContext: any): void;
    };
    new (props: import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>, context: any): {
        state: {
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        };
        componentDidMount(): void;
        componentDidUpdate({ authClient: prevAuthClient, initOptions: prevInitOptions, }: import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>): void;
        init(): void;
        onError: (event: import("@baolq/react-keycloak-core").AuthClientEvent) => (error?: import("@baolq/react-keycloak-core").AuthClientError | undefined) => void;
        updateState: (event: import("@baolq/react-keycloak-core").AuthClientEvent) => () => void;
        refreshToken: (event: import("@baolq/react-keycloak-core").AuthClientEvent) => () => void;
        render(): JSX.Element;
        context: any;
        setState<K_1 extends keyof {
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>(state: {
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        } | Pick<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }, K_1> | ((prevState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>, props: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>) => {
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        } | Pick<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }, K_1> | null) | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>> & Readonly<{
            children?: import("react").ReactNode;
        }>;
        refs: {
            [key: string]: import("react").ReactInstance;
        };
        shouldComponentUpdate?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: import("react").ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, prevState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>): any;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<import("@baolq/react-keycloak-core").AuthProviderProps<import("keycloak-js").KeycloakInstance>>, nextState: Readonly<{
            initialized: boolean;
            isAuthenticated: boolean;
            isLoading: boolean;
        }>, nextContext: any): void;
    };
    contextType?: import("react").Context<any> | undefined;
};
